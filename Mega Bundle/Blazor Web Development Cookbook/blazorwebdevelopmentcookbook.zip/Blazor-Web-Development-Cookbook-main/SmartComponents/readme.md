Initial projects copied from the Smart Components repository:
- https://github.com/dotnet/smartcomponents
All credits to the Team maintaining that repository.

As part of BlazorCookbook repository:
- I've updated `Azure.AI.OpenAI` package to latest `2.0.0.` version
- and refactored `OpenAIInferenceBacked` service as it was no longer compatible
- I've also removed the self-hosted AI option as it was not needed for the purpose of the book