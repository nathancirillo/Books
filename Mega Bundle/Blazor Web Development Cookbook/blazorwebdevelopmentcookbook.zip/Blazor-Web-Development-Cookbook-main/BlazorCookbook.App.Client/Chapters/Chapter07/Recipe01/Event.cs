﻿namespace BlazorCookbook.App.Client.Chapters.Chapter07.Recipe01;

public class Event
{
    public string Name { get; set; }
}