﻿using Microsoft.AspNetCore.Components.Forms;

namespace BlazorCookbook.App.Client.Chapters.Chapter06.Recipe05;

public class EventCover
{
    public IBrowserFile File { get; set; }
}
