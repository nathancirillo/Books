﻿namespace BlazorCookbook.App.Client.Chapters.Chapter04.Recipe04;

public record PaginateEventArgs(int Page, int Size);