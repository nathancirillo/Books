﻿namespace BlazorCookbook.App.Client.Chapters.Chapter04.Recipe03;

public record PaginateEventArgs(int Page, int Size);