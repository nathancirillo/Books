﻿namespace BlazorCookbook.App.Client.Chapters.Chapter02.Data;

public record SkillLevel(int Id, string Title);