﻿namespace Chapter9.Interfaces
{
    public interface IShipment
    {
        string Description { get; set; }
        int Id { get; set; }
        string Type { get; set; }
    }
}
