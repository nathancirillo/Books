<template>
    <div>
        <h1>This is the About View</h1>
    </div>
</template>
