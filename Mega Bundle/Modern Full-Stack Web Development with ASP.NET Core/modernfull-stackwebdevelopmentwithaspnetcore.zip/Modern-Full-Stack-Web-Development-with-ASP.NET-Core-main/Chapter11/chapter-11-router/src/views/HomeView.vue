<template>
    <div>
        <h1>This is the Home View</h1>
    </div>
</template>
