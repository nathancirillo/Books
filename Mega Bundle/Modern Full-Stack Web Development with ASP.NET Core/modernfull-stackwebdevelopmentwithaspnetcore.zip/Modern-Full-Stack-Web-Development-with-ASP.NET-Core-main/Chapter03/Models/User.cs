﻿namespace Chapter03.Models
{
    public class User
    {
    }
}
