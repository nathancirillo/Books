﻿namespace Chapter03.Services
{
    public class FileLoggingService:ILoggingService
    {
    }
}
