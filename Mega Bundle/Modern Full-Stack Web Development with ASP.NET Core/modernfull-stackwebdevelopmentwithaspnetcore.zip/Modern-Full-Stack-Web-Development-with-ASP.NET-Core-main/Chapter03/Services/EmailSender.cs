﻿namespace Chapter03.Services
{
    public class EmailSender:IEmailSender
    {
    }
}
