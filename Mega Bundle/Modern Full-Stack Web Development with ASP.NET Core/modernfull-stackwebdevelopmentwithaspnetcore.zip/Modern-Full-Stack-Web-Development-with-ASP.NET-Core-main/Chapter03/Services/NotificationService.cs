﻿namespace Chapter03.Services
{
    public class NotificationService: INotificationService
    {
        public void SendNotification(string message)
        {

            // Code to send notification 

        }

    }
}
