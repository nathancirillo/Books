﻿namespace Chapter03.Services
{
    public interface IComplexService
    {
    }
}
