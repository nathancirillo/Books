import React from 'react';

function MyComponent() {
  return (
    <div className="my-component">
      <h2>This is my first component!</h2>
      <p>Congratulations for your first component.</p>
    </div>
  );
}

export default MyComponent;
