﻿namespace Chapter6
{
    public class SharedStateService
    {
        public string Message { get; set; }
    }
}
