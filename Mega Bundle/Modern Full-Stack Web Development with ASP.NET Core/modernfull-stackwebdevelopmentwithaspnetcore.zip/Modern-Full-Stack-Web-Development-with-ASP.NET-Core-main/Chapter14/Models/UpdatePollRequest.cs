﻿namespace Chapter14.Models
{
    public class UpdatePollRequest
    {
        public DateTime ExpiresAt { get; set; }
    }
}
