import { Component } from '@angular/core';

@Component({
  selector: 'app-test-form',
  standalone: true,
  imports: [],
  templateUrl: './test-form.component.html',
  styleUrl: './test-form.component.css'
})
export class TestFormComponent {

}
