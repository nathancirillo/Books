﻿namespace Chapter13.Models
{
    public class FitnessGoal
    {
        public int Id { get; set; }
        public string GoalName { get; set; }
        public string Description { get; set; }
        public DateTime TargetDate { get; set; }
    }
}
