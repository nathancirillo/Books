﻿namespace GrpcDemo.Services;

public class InvoiceService : GrpcDemo.Invoice.InvoiceBase
{
    public InvoiceService()
    {
    }
}

