﻿namespace SchoolManagement.Models;

public enum CourseType
{
    Core,
    Elective,
    Lab
}