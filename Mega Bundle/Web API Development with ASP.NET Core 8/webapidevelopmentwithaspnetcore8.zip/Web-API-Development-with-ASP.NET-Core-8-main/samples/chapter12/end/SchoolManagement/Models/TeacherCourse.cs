﻿namespace SchoolManagement.Models;

public class TeacherCourse
{
    public Guid TeacherId { get; set; }
    public Guid CourseId { get; set; }
}
