﻿using Microsoft.AspNetCore.Identity;

namespace ClaimBasedAuthorizationDemo.Authentication;

public class AppUser : IdentityUser
{
}
