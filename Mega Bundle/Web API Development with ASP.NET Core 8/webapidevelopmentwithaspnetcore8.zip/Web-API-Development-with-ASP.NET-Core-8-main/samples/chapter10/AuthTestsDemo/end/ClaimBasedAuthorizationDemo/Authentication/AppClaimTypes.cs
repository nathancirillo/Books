﻿namespace ClaimBasedAuthorizationDemo.Authentication;

public static class AppClaimTypes
{
    public const string DrivingLicenseNumber = "DrivingLicenseNumber";
    public const string AccessNumber = "AccessNumber";
}
