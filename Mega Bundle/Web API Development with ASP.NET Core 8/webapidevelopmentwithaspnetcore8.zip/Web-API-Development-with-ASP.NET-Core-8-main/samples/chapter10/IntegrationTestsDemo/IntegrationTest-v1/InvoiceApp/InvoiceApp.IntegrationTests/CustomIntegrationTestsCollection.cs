﻿namespace InvoiceApp.IntegrationTests;
[CollectionDefinition("CustomIntegrationTests")]
public class CustomIntegrationTestsCollection : ICollectionFixture<CustomIntegrationTestsFixture>
{
}
