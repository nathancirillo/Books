﻿using Microsoft.AspNetCore.Mvc.Testing;

namespace InvoiceApp.IntegrationTests;
public class IntegrationTestsFixture : WebApplicationFactory<Program>
{
}
