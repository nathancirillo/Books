﻿global using Codebreaker.Data.SqlServer;
global using Codebreaker.GameAPIs.Data;
global using Codebreaker.GameAPIs.Data.InMemory;
global using Codebreaker.GameAPIs.Endpoints;
global using Codebreaker.GameAPIs.Exceptions;
global using Codebreaker.GameAPIs.Extensions;
global using Codebreaker.GameAPIs.Models;
global using Codebreaker.GameAPIs.Services;

global using Microsoft.EntityFrameworkCore;
