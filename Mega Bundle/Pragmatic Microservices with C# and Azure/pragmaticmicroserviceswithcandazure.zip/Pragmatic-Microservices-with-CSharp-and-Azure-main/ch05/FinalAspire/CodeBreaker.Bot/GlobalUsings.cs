﻿global using System.Collections.Concurrent;
global using CodeBreaker.Bot;
global using Codebreaker.GameAPIs.Client;