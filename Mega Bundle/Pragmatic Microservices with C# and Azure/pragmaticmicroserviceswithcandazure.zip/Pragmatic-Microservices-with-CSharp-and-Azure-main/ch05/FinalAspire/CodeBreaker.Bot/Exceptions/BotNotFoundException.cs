﻿namespace CodeBreaker.Bot.Exceptions;

public class BotNotFoundException : Exception
{
}
