﻿namespace CodeBreaker.Bot.Api;

public record StatusResponse(
    int GameNumber,
    string Message
);
