﻿namespace Codebreaker.GameAPIs.Models;

public class FieldCategories
{
    public const string Colors = "colors";
    public const string Shapes = "shapes";
}
