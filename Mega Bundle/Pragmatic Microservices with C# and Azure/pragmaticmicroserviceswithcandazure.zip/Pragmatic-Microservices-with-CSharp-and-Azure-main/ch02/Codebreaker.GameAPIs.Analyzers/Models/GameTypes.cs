﻿namespace Codebreaker.GameAPIs.Models;

public class GameTypes
{
    public const string Game6x4 = nameof(Game6x4);
    public const string Game6x4Mini = nameof(Game6x4Mini);
    public const string Game8x5 = nameof(Game8x5);
    public const string Game5x5x4 = nameof(Game5x5x4);
}
