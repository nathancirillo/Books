﻿global using Codebreaker.GameAPIs.Models;
