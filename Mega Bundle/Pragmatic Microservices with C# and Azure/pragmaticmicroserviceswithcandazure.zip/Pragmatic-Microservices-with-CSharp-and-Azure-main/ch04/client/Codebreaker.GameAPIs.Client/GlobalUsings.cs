﻿global using System.Net;
global using System.Net.Http.Json;
global using System.Text.Json;
global using System.Text.Json.Serialization;

global using Codebreaker.GameAPIs.Client.Models;