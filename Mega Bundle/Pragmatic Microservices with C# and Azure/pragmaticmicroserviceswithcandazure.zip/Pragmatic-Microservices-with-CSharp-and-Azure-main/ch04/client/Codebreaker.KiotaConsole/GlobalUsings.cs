﻿global using System.Text.Json;

global using Codebreaker.Client;
global using Codebreaker.Client.Models;

global using Microsoft.Extensions.DependencyInjection;
global using Microsoft.Extensions.Hosting;
global using Microsoft.Extensions.Options;
global using Microsoft.Kiota.Abstractions;
global using Microsoft.Kiota.Abstractions.Authentication;
global using Microsoft.Kiota.Http.HttpClientLibrary;

global using Spectre.Console;
