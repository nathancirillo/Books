﻿global using Codebreaker.Client;
global using Codebreaker.GameAPIs.Client;
global using Codebreaker.GameAPIs.Client.Models;

global using Microsoft.Extensions.DependencyInjection;
global using Microsoft.Extensions.Hosting;

global using Spectre.Console;
