﻿global using Codebreaker.Data.Cosmos.Utilities;
global using Codebreaker.GameAPIs.Data;
global using Codebreaker.GameAPIs.Models;

global using Microsoft.EntityFrameworkCore;
