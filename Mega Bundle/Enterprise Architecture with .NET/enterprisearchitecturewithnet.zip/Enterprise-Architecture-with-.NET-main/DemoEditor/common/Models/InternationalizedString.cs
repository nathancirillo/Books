namespace DemoEditor.Models;

public class InternationalizedString
{
    public string Lang { get; set; }

    public string Value { get; set; }
}