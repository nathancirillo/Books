namespace DemoEditor.Models;

public class Link
{
    public string Rel { get; set; }

    public string Href { get; set; }

    public string Title { get; set; }
}