﻿// SWIMMING POOLS
// Chapter 6 (Dictionaries and Sets)
// C# Data Structures and Algorithms, Second Edition

public enum PoolTypeEnum
{
    Recreation,
    Competition,
    Thermal, 
    Kids
};
