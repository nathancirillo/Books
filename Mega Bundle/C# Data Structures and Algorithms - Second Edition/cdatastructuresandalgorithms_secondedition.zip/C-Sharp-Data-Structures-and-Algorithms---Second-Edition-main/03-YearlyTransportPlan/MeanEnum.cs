﻿// YEARLY TRANSPORT PLAN
// Chapter 3 (Arrays and Sorting)
// C# Data Structures and Algorithms, Second Edition

public enum MeanEnum
{
    Car,
    Bus,
    Subway,
    Bike,
    Walk
}
