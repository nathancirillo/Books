﻿// LIST OF PEOPLE
// Chapter 4 (Variants of Lists)
// C# Data Structures and Algorithms, Second Edition

public record Person(string Name, int Age, string Country);
