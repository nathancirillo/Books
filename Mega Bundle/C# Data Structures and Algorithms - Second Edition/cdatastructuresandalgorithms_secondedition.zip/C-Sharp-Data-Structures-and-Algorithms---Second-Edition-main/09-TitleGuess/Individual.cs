﻿// TITLE GUESS
// Chapter 9 (See in Action)
// C# Data Structures and Algorithms, Second Edition

record Individual(string Chromosome, int Fitness);
