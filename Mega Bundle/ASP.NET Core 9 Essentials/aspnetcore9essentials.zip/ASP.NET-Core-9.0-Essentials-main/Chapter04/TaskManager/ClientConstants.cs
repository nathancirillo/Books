namespace TaskManager;

public sealed class ClientConstants
{
    public const string NOTIFY_TASK_MANAGER_EVENT = "TaskManagerEvent";
}