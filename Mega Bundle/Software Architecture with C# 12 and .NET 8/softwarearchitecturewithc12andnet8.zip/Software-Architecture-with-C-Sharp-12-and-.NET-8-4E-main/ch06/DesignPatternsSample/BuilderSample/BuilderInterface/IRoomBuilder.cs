﻿namespace DesignPatternsSample.BuilderSample.BuilderInterface
{
    public interface IRoomBuilder
    {
        Room Build();
    }
}
