﻿namespace DesignPatternsSample.FactorySample.Enums
{
    public enum EnumChargingOptions
    {
        CreditCard,
        DebitCard
    }
}