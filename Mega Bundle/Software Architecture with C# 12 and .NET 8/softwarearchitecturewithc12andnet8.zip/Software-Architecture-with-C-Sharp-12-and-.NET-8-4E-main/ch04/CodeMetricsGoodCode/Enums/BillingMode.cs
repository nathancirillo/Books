﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeMetricsGoodCode.Enums
{
    enum BillingMode
    {
        Mode01 = 1,
        Mode02,
        Mode03,
        Mode04,
        Mode05,
        Mode06,
        Mode07,
        Mode08,
    }
}
