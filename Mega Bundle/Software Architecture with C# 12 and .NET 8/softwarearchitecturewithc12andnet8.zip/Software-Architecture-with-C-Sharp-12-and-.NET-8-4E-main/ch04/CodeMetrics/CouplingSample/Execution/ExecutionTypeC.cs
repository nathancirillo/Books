﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CodeMetricsBadCode.CouplingSample.Execution
{
    class ExecutionTypeC
    {
        public void ExecuteTypeC()
        {

        }
    }
}
