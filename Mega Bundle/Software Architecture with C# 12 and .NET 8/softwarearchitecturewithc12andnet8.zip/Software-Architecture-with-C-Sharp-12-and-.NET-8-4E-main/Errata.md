## Errata
- Errata Page: 222, 223

    Errata Description :
    
    In the example code sections of class "MyTestsClass", the constructor should be "MyTestsClass" instead of "MyDatabaseTests".

- Errata Page: 226

    Errata Description :
    
    In the example code sections of class "MyUnitTestClass", the constructor should be "UnitTest1" instead of "MyUnitTestClass".

- Errata Page: 228

    Errata Description :
    Typo in the method submitButton.Clikck(); should be submitButton (".Click()")

- Errata Page: 21

    Errata Description :
    Typo in the week references; should be weak references
