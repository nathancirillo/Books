﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Recommendation
{
    public class Place
    {
        public int PlaceId { get; set; }
        public int PlaceName { get; set; }
    }
}