﻿namespace Vehicles.HighEnd;

public class HighEndVehicleFactoryTest : BaseAbstractFactoryTest<HighEndVehicleFactory, HighEndCar, HighEndBike> { }
