﻿namespace Vehicles.LowEnd;

public class LowEndVehicleFactoryTest : BaseAbstractFactoryTest<LowEndVehicleFactory, LowEndCar, LowEndBike> { }
