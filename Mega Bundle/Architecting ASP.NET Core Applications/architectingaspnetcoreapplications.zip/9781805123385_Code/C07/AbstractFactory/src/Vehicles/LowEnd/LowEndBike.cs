﻿namespace Vehicles.LowEnd;

public class LowEndBike : IBike { }
