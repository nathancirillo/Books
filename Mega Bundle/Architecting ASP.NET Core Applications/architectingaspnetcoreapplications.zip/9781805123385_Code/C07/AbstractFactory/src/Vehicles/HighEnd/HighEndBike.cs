﻿namespace Vehicles.HighEnd;

public class HighEndBike : IBike { }
