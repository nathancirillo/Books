﻿namespace Vehicles;

public interface ICar { }
