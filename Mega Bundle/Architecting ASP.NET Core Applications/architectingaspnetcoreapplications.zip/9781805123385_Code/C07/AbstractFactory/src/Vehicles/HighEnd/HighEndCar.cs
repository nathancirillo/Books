﻿namespace Vehicles.HighEnd;

public class HighEndCar : ICar { }
