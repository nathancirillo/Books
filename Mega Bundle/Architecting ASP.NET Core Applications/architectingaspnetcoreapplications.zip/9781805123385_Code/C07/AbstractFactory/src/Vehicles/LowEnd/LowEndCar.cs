﻿namespace Vehicles.LowEnd;

public class LowEndCar : ICar { }
