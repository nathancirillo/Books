﻿namespace Vehicles.MidRange;

public class MidRangeCar : ICar { }
