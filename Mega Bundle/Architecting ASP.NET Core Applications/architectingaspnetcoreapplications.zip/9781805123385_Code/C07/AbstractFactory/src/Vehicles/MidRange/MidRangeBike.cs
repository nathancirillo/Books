﻿namespace Vehicles.MidRange;

public class MidRangeBike : IBike { }
