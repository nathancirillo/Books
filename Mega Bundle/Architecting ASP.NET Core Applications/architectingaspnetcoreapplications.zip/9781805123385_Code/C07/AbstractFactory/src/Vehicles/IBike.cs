﻿namespace Vehicles;

public interface IBike { }
