﻿namespace OpaqueFacadeSubSystem;

// Subsystem: Shipping
internal class ShippingService
{
    public void ScheduleShipping(int orderId)
    {
        // Logic to schedule shipping
    }
}
