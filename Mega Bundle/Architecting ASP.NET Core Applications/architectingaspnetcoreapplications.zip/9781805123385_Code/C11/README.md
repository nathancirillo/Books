# Chapter 11

The whole BookStore project data structure is available in the [all.json](all.json) file.
