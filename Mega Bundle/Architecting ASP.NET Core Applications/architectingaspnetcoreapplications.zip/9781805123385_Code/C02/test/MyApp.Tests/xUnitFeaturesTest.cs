﻿namespace MyApp;

public partial class xUnitFeaturesTest
{
    // See xUnitFeaturesTest.*.cs files for nested classes.
}
