﻿namespace Variance;

public record class Weapon { }
public record class Sword : Weapon { }
public record class TwoHandedSword : Sword { }
