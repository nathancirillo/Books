﻿namespace Abstractions;

public interface IDataPersistence
{
    void Persist();
}