﻿namespace AfterSRP;

public record class Product(int Id, string Name);