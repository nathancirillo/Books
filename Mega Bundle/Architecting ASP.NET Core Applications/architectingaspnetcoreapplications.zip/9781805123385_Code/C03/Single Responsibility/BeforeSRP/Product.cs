﻿namespace BeforeSRP;

public record class Product(int Id, string Name);