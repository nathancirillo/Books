﻿namespace OCP;

public record class Entity();

