﻿namespace Factory.Models;
public record class Location(int Id, string Name, string CountryCode);
