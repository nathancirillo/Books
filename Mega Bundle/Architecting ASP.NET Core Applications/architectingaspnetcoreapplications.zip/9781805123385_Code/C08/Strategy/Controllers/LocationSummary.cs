﻿namespace Strategy.Controllers;
public record class LocationSummary(int Id, string Name);