﻿namespace ValidateOptionsResultBuilder;

public class MyOptions
{
    public string? Prop1 { get; set; }
    public string? Prop2 { get; set; }
}
