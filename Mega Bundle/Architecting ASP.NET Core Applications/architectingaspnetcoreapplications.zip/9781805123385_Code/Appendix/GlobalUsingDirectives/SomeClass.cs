﻿
namespace GlobalUsingDirectives.SomeCoolNamespace;

public class SomeClass
{

}
