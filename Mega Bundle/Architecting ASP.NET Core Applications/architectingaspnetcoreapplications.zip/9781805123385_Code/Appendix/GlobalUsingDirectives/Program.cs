﻿
Console.WriteLine(typeof(SomeClass).FullName);
