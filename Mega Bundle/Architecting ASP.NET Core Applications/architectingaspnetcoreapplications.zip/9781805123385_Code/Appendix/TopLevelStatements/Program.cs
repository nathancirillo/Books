using System;
Console.WriteLine("Hello world!");