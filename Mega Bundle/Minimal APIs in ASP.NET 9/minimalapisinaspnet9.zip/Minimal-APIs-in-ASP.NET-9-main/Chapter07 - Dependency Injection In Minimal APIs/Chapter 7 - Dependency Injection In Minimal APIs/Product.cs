﻿namespace Chapter_7___Dependency_Injection_In_Minimal_APIs
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public float RRP { get; set; }
    }
}
