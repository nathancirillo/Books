﻿namespace Chapter_14
{
    public class CalculatorService
    {
        public int Sum(int[] numbers)
        {
            return numbers.Sum();
        }
    }
}
