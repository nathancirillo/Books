﻿// See https://aka.ms/new-console-template for more information

using ExtensionLibrary;
using Windows_Messages;

"Beginning the windows messages sample".Dump(ConsoleColor.DarkCyan);
WindowManager.CreateWindow();

"Created".Dump(ConsoleColor.DarkCyan);

Console.ReadLine();
"Ending the windows messages sample".Dump(ConsoleColor.DarkCyan);