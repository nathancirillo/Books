﻿namespace JSON_RPC.Commands
{
    [Serializable]
    internal class ShowDateCommand
    {
        public bool IncludeTime { get; set; }
    }
}
