﻿
namespace ThreadSafety
{
    record Counter(int InitialValue);
}
