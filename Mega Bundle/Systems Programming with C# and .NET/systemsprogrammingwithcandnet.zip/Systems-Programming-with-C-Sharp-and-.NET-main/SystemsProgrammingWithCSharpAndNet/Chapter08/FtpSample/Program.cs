﻿using FtpSample;

FtpClientNewStyle.FetchDirectoryContents("ftp://ftp.example.com", "username", "password");

FtpClientOldStyle.FetchDirectoryContents("ftp://ftp.example.com", "username", "password");
