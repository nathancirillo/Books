﻿using ExtensionLibrary;

"This is an awesome piece of software!".Dump(ConsoleColor.Cyan);
"Press any key to exit...".Dump(ConsoleColor.Yellow);
Console.ReadKey();
"Thanks and bye!".Dump(ConsoleColor.Cyan);
