﻿using Profiling;

PrimeCalculator pc = new PrimeCalculator();
pc.Run();