**Tools in JetBrains Rider**

- [JetBrains annual survey](#jetbrains-annual-survey)
- [Code Snippets](#code-snippets)
- [Editor configuration](#editor-configuration)
- [AI Companions: JetBrains AI Assistant](#ai-companions-jetbrains-ai-assistant)


# JetBrains annual survey

Review JetBrains annual survey of the developer ecosystem at the following link: https://www.jetbrains.com/lp/devecosystem-2023/.

# Code Snippets



# Editor configuration

https://blog.jetbrains.com/dotnet/2023/07/18/editorconfig-code-style-and-configuring-code-inspections.

# AI Companions: JetBrains AI Assistant

