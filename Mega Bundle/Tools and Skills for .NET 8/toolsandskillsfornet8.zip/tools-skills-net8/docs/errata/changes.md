**Post-Publication Changes** (0 items)

If you find any changes made to C#, .NET, code editors, or other tools since publication, then please [raise an issue in this repository](https://github.com/markjprice/tools-skills-net8/issues) or email me at markjprice (at) gmail.com.

None so far.