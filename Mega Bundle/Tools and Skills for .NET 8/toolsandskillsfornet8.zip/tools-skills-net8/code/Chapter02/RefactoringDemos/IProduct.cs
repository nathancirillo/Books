﻿public interface IProduct
{
  string? Description { get; set; }
}