﻿Product product = new()
{
  Description = "Seafood"
};

WriteLine(product.Description);
