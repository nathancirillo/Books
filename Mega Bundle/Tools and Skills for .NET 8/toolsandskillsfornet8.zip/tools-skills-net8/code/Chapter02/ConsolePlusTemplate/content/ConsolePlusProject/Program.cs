﻿ConfigureConsole(); // en-US by default.

// Alternatives:
// ConfigureConsole("fr-FR"); // French in France.
// ConfigureConsole(useComputerCulture: true); // Your local culture.

// Add your code below here:
