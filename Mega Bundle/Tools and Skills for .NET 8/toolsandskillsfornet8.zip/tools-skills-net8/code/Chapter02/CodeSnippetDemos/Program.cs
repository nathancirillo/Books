﻿ConfigureConsole();
WriteLine(CurrentDirectory);
