﻿ConfigureConsole();
