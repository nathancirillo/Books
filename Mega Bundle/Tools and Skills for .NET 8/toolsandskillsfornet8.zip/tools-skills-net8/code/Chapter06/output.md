# Mermaid in Markdown
<table><tr><th>Flowchart</th>
<th>Class diagram</th></tr><tr><td>

![diagram](./output-1.svg)
</td><td>

![diagram](./output-2.svg)
</td></td></table>

![diagram](./output-3.svg)

![diagram](./output-4.svg)