﻿using PacktLibrary; // To use Utility.

Utility.ConfigureConsole();
Utility.WriteLineInColor(
  text: Utility.CurrentConsoleCulture(), 
  color: ConsoleColor.Red);
