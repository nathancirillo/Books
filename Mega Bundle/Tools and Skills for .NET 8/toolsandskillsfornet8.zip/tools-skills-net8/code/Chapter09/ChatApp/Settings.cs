﻿public sealed class Settings
{
  public required string ModelId { get; set; }
  public required string OpenAISecretKey { get; set; }
}
