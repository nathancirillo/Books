﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, Git!");
Console.WriteLine(Calculator.Add(2, 3));
