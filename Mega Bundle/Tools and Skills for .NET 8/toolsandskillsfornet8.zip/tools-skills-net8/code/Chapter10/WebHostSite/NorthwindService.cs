﻿namespace Packt.Shared;

public interface INorthwindService
{
}

public class NorthwindService : INorthwindService
{
}
