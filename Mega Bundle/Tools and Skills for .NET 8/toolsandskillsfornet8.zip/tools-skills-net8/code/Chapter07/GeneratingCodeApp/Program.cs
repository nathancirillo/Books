﻿Message("Hello from some source generator code.");
