﻿partial class Program
{
  static partial void Message(string message);
}
