namespace Packt.Shared;

public record Customer(string Name, 
  string CreditCard, string Password);
