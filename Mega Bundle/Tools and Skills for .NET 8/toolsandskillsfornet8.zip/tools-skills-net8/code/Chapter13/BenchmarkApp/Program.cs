﻿using BenchmarkDotNet.Running; // To use BenchmarkRunner.

// BenchmarkRunner.Run<StringBenchmarks>();
// BenchmarkRunner.Run<FibonacciBenchmarks>();
BenchmarkRunner.Run<SortingBenchmarks>();
