﻿export function showAlert(message) {
    return alert(message);
} 