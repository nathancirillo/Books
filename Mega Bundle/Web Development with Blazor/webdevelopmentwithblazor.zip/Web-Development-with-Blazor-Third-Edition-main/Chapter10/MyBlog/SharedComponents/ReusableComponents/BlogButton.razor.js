export function showConfirm(message) {
    return confirm(message);
}
