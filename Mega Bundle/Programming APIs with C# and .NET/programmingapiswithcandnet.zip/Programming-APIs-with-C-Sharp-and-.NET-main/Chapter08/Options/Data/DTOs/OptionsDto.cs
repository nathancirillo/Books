﻿namespace Cars.Data.DTOs
{
    public class OptionsDto
    {
        public int OptionId { get; set; }
        public string OptionName { get; set; }
        public float OptionPrice { get; set; }
    }
}
