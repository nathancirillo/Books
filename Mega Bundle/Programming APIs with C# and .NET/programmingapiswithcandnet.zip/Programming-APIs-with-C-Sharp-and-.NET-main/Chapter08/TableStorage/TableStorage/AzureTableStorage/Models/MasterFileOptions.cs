﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureTableStorage.Models
{
    public class MasterFileOptions
    {
        public string TableName { get; set; } = "MasterFile";
    }
}
