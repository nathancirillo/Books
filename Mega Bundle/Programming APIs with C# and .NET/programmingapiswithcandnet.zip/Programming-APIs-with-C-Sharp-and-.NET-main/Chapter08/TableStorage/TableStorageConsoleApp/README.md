# TableStorageConsoleApp
This is a demo program illustrating Table Storage on Azure.
Please see license.