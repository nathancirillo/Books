﻿namespace TableStorageConsoleApp.Models
{
    public class TableModelOptions
    {
        public string TableName { get; set; } = "ExceptionsFile";
    }
}
