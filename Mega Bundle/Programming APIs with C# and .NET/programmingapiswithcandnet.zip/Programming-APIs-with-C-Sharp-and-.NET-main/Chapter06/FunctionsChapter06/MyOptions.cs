﻿namespace FunctionChapter6
{
    public class MyOptions
    {
        public string? MyReturnProperty { get; set; } = "my value in code";
    }
}
