

public class PatToken
{
    public required string Value { get; set; }
    public bool IsExpired { get; set; }
}