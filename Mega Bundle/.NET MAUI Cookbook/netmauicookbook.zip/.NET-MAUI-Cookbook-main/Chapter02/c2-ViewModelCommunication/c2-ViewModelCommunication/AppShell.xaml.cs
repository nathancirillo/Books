﻿namespace c2_ViewModelCommunication {
    public partial class AppShell : Shell {
        public AppShell() {
            InitializeComponent();
        }
    }
}
