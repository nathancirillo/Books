﻿using CommunityToolkit.Mvvm.Messaging;

namespace c2_ViewModelCommunication {
    public partial class MainPage : ContentPage {
        public MainPage() {
            InitializeComponent();
        }
    }
}
