namespace c2_ViewModelCommunication.Views;

public partial class SecurityMonitorView : ContentView
{
	public SecurityMonitorView()
	{
		InitializeComponent();
	}
}