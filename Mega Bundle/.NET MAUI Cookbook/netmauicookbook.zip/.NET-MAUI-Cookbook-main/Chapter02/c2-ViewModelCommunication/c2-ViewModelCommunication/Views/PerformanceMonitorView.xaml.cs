namespace c2_ViewModelCommunication.Views;

public partial class PerformanceMonitorView : ContentView
{
	public PerformanceMonitorView()
	{
		InitializeComponent();
	}
}