namespace c2_ViewModelCommunication.Views;

public partial class AlertGeneratorView : ContentView
{
	public AlertGeneratorView()
	{
		InitializeComponent();
	}
}