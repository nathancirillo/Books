﻿using Microsoft.Extensions.DependencyInjection;
using System;
using static System.Formats.Asn1.AsnWriter;

namespace c2_DecoupleViewAndViewModel {
    public partial class MainPage : ContentPage {
        public MainPage() {
            InitializeComponent();
        }
    }
}
