﻿namespace c2_DecoupleViewAndViewModel {
    public partial class MainPage : ContentPage {
        public MainPage() {
            InitializeComponent();
        }
    }

}
