﻿namespace c2_TroubleshootBindings {
    public partial class AppShell : Shell {
        public AppShell() {
            InitializeComponent();
        }
    }
}
