﻿namespace c3_DarkAndLightThemes {
    public partial class AppShell : Shell {
        public AppShell() {
            InitializeComponent();
        }
    }
}
