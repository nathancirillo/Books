﻿namespace c3_CustomAnimations {
    public partial class AppShell : Shell {
        public AppShell() {
            InitializeComponent();
        }
    }
}
