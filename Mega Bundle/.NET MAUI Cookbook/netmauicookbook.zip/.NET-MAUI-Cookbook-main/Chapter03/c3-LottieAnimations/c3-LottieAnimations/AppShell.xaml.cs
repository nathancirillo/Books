﻿namespace c3_LottieAnimations {
    public partial class AppShell : Shell {
        public AppShell() {
            InitializeComponent();
            
           
        }
    }
}
