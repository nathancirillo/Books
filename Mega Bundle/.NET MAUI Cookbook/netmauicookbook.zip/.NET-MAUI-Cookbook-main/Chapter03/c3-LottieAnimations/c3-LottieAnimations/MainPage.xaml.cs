﻿using SkiaSharp.Extended.UI.Controls;

namespace c3_LottieAnimations {
    public partial class MainPage : ContentPage {
        public MainPage() {
            InitializeComponent();
        }
    }

}
