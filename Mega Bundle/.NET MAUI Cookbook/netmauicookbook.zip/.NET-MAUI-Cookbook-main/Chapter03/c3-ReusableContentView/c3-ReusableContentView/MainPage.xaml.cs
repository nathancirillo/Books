﻿namespace c3_ReusableContentView {
    public partial class MainPage : ContentPage {
        public MainPage() {
            InitializeComponent();
        }
    }
}
