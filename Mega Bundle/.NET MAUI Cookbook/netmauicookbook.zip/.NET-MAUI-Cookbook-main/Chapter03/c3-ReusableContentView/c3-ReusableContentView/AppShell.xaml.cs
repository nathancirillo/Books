﻿namespace c3_ReusableContentView {
    public partial class AppShell : Shell {
        public AppShell() {
            InitializeComponent();
        }
    }
}
