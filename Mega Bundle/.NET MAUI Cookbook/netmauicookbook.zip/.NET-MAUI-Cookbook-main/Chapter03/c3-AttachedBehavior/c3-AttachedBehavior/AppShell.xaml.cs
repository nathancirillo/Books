﻿namespace c3_AttachedBehavior {
    public partial class AppShell : Shell {
        public AppShell() {
            InitializeComponent();
        }
    }
}
