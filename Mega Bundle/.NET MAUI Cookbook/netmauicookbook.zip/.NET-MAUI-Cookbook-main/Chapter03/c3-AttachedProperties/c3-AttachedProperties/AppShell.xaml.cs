﻿namespace c3_AttachedProperties {
    public partial class AppShell : Shell {
        public AppShell() {
            InitializeComponent();
        }
    }
}
