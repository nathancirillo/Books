﻿namespace c1_OrientationSpecificSettings {
    public partial class AppShell : Shell {
        public AppShell() {
            InitializeComponent();
        }
    }
}
