﻿namespace c1_HorizontalAndVerticalLayouts {
    public partial class MainPage : ContentPage {

        public MainPage() {
            InitializeComponent();
        }
    }

}
