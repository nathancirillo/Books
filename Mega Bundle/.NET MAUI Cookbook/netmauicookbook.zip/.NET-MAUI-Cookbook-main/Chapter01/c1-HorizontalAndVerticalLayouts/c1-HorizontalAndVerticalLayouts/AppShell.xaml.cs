﻿namespace c1_HorizontalAndVerticalLayouts {
    public partial class AppShell : Shell {
        public AppShell() {
            InitializeComponent();
        }
    }
}
