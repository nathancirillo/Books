﻿namespace c1_GridLayouts {
    public partial class MainPage : ContentPage {
        public MainPage() {
            InitializeComponent();
        }
    }

}
