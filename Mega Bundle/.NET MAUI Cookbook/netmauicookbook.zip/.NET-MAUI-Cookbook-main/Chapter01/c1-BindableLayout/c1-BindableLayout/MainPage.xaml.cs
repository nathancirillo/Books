﻿namespace c1_BindableLayout {
    public partial class MainPage : ContentPage {

        public MainPage() {
            InitializeComponent();
        }
    }

}
