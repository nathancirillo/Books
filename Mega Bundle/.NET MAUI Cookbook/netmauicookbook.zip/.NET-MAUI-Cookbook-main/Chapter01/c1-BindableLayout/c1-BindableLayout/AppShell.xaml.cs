﻿namespace c1_BindableLayout {
    public partial class AppShell : Shell {
        public AppShell() {
            InitializeComponent();
        }
    }
}
