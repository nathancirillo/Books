namespace c1_DeviceSpecificLayout;

public partial class PhoneView : ContentView
{
	public PhoneView()
	{
		InitializeComponent();
	}
}