﻿namespace c1_DeviceSpecificLayout {
    public partial class AppShell : Shell {
        public AppShell() {
            InitializeComponent();
        }
    }
}
