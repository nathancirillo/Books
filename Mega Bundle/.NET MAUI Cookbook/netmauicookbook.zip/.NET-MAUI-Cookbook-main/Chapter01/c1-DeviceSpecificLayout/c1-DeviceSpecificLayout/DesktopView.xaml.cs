namespace c1_DeviceSpecificLayout;

public partial class DesktopView : ContentView
{
	public DesktopView()
	{
		InitializeComponent();
	}
}