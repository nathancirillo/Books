﻿
namespace c1_DeviceSpecificLayout {
    public partial class MainPage : ContentPage {
        public MainPage() {
            InitializeComponent();
        }
    }
}
