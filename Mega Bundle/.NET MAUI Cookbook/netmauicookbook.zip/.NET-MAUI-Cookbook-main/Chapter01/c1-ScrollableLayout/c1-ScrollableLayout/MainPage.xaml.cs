﻿namespace c1_ScrollableLayout {
    public partial class MainPage : ContentPage {
        public MainPage() {
            InitializeComponent();
        }
    }
}
