﻿namespace c1_ScrollableLayout {
    public partial class AppShell : Shell {
        public AppShell() {
            InitializeComponent();
        }
    }
}
