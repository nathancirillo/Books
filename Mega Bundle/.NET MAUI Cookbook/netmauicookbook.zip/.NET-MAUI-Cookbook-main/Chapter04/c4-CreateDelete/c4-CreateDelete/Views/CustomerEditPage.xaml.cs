namespace c4_LocalDatabaseConnection.Views;

public partial class CustomerEditPage : ContentPage
{
	public CustomerEditPage()
	{
		InitializeComponent();
	}
}