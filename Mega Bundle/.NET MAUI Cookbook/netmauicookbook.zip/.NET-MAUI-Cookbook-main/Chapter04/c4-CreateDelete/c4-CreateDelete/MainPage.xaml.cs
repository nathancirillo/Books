﻿namespace c4_LocalDatabaseConnection {
    public partial class MainPage : ContentPage {
        public MainPage() {
            InitializeComponent();
        }
    }

}
