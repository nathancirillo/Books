﻿using BenchmarkDotNet.Running;

BenchmarkRunner.Run<StringBenchmarks>();