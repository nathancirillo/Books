﻿namespace Northwind.Grpc.Client.Mvc.Models;

public class HomeIndexViewModel
{
  public string? Greeting { get; set; }
  public string? ShipperSummary { get; set; }
  public string? ErrorMessage { get; set; }
}
