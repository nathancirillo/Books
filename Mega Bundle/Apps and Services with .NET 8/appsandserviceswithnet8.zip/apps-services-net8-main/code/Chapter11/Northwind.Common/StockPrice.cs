﻿namespace Northwind.SignalR.Streams;

public record StockPrice(string Stock, double Price);
