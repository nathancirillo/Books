﻿namespace Northwind.Maui.Client.Controls;

public enum Theme
{
  System,
  Light,
  Dark
}
