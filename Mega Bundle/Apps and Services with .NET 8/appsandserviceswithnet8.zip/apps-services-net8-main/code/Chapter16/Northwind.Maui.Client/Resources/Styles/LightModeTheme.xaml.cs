namespace Northwind.Maui.Client.Resources.Styles;

public partial class LightModeTheme : ResourceDictionary
{
	public LightModeTheme()
	{
		InitializeComponent();
	}
}