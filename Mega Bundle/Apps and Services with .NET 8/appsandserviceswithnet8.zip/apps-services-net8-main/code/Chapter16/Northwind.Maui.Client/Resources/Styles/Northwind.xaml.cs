namespace Northwind.Maui.Client.Resources.Styles;

public partial class Northwind : ResourceDictionary
{
	public Northwind()
	{
		InitializeComponent();
	}
}