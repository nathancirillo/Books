namespace Northwind.Maui.Client.Resources.Styles;

public partial class SystemModeTheme : ResourceDictionary
{
	public SystemModeTheme()
	{
		InitializeComponent();
	}
}