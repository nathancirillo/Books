namespace Northwind.Maui.Client.Resources.Styles;

public partial class DarkModeTheme : ResourceDictionary
{
	public DarkModeTheme()
	{
		InitializeComponent();
	}
}