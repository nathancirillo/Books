namespace Northwind.Maui.Client.Resources.Styles;

public partial class LightDarkModeColors : ResourceDictionary
{
	public LightDarkModeColors()
	{
		InitializeComponent();
	}
}