namespace Northwind.Maui.Blazor.Client;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}