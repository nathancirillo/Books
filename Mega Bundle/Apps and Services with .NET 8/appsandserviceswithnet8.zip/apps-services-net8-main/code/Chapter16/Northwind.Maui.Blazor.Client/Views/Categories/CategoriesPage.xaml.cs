namespace Northwind.Maui.Blazor.Client.Views;

public partial class CategoriesPage : ContentPage
{
	public CategoriesPage()
	{
		InitializeComponent();
	}
}