namespace Northwind.Maui.Blazor.Client.Views;

public partial class CategoryPage : ContentPage
{
	public CategoryPage()
	{
		InitializeComponent();
	}
}