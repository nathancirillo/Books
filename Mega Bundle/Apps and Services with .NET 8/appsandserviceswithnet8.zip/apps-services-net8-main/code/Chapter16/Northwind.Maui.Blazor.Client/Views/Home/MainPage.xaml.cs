﻿namespace Northwind.Maui.Blazor.Client.Views;

public partial class MainPage : ContentPage
{
	public MainPage()
	{
		InitializeComponent();
	}
}
