﻿namespace Serilogging.Models;

public class ProductPageView
{
  public int ProductId { get; set; }
  public string? PageTitle { get; set; }
  public string? SiteSection { get; set; }
}
