﻿namespace FluentValidation.Models;

public enum CustomerLevel
{
  Bronze,
  Silver,
  Gold
}
