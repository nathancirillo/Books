﻿namespace GeneratingPdf.Models;

public class Catalog
{
  public List<Category> Categories { get; set; } = null!;
}
