﻿ConfigureConsole(); // Defaults to en-US culture.

/*
OutputCasings("The cat sat on the mat.");
OutputCasings("THE CAT SAT ON THE MAT.");
OutputCasings("the cat sat on the mat. the frog jumped.");
*/

//OutputSpacingAndDashes();

//OutputEnumNames();

//NumberFormatting();

DateTimeFormatting();
