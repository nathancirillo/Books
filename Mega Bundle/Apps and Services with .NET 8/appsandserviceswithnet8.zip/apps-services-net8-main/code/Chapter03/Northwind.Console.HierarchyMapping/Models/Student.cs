﻿namespace Northwind.Models;

public class Student : Person
{
  public string? Subject { get; set; }
}
