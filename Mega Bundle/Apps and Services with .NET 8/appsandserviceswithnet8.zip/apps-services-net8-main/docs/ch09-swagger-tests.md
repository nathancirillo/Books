# Swagger Tests

In this online-only section, you will see how to use the Swagger documentation user interface to test performing CRUD operations (POST, PUT, DELETE) on a Web API service.

> To complete this section, you must have created the `Northwind.WebApi.Service` project as described in the **Building a controller-based Web API service** section in Chapter 9 of the book.

